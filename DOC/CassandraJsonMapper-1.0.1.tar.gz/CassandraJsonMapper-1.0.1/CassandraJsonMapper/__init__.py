from CassandraJsonMapper import db

__version_info__ = (1, 0, 1)
__version__ = '.'.join(map(str, __version_info__))
